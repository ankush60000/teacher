﻿Imports MySql.Data.MySqlClient

Public Class sigin
    Dim Gender As String
    Dim Query As String
    Dim mysqlconn As New MySqlConnection
    Dim previous As Main
    Dim command As MySqlCommand
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        'MaximizeBox = False  
        'MinimizeBox = False  


    End Sub

    Private Sub male_CheckedChanged(sender As Object, e As EventArgs) Handles male.CheckedChanged
        Gender = "Male"
    End Sub
    Private Sub female_CheckedChanged(sender As Object, e As EventArgs) Handles female.CheckedChanged
        Gender = "Female"
    End Sub



    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If Password.Text <> Reenter.Text Then
            MessageBox.Show("Password MisMatched")
            Password.Clear()
            Reenter.Clear()
        End If

        If Teacherid.Text = "" Or FirstName.Text = "" Or LastName.Text = "" Or Email.Text = "" Or MobileNumber.Text = "" Or Address.Text = "" Or DOB.Text = "" Or Password.Text = "" Or Reenter.Text = "" Then

            MessageBox.Show("All feilds are must")
        Else
            mysqlconn = New MySqlConnection
            mysqlconn.ConnectionString = "server=localhost;user=root;database=Teacherpanel;port=3306;password=;"
            Dim Reader As MySqlDataReader

            Try
                mysqlconn.Open()
                Query = " insert into faculty(ID,Fname,Lname,Email,MobileNumber,Address,DOB,Password,Gender)values('" & Teacherid.Text.ToString & "','" & FirstName.Text.ToString & "','" & LastName.Text.ToString & "','" & Email.Text.ToString & "', '" & MobileNumber.Text.ToString & "','" & Address.Text.ToString & "', '" & DOB.Text.ToString & "' , '" & Password.Text.ToString & "', '" & Gender & "' )"
                command = New MySqlCommand(Query, mysqlconn)
                Reader = command.ExecuteReader
                MessageBox.Show("Account Created")
                mysqlconn.Close()
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)
            Finally
                mysqlconn.Dispose()
            End Try
        End If


    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub
End Class