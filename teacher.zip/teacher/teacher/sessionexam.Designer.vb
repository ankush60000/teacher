﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class sessionexam
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PassingMarks = New System.Windows.Forms.TextBox()
        Me.passm = New System.Windows.Forms.Label()
        Me.Maxmarks = New System.Windows.Forms.TextBox()
        Me.Maxm = New System.Windows.Forms.Label()
        Me.Duration = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.startexam = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NoofQ = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Semester = New System.Windows.Forms.ComboBox()
        Me.Subjectcode = New System.Windows.Forms.TextBox()
        Me.Subcode = New System.Windows.Forms.Label()
        Me.SubjectName = New System.Windows.Forms.TextBox()
        Me.Subname = New System.Windows.Forms.Label()
        Me.Sem = New System.Windows.Forms.Label()
        Me.Course = New System.Windows.Forms.TextBox()
        Me.Crse = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(12, 694)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'PassingMarks
        '
        Me.PassingMarks.AutoCompleteCustomSource.AddRange(New String() {"15", "30"})
        Me.PassingMarks.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.PassingMarks.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.PassingMarks.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PassingMarks.Location = New System.Drawing.Point(370, 424)
        Me.PassingMarks.Name = "PassingMarks"
        Me.PassingMarks.Size = New System.Drawing.Size(289, 28)
        Me.PassingMarks.TabIndex = 31
        '
        'passm
        '
        Me.passm.AutoSize = True
        Me.passm.Font = New System.Drawing.Font("Microsoft Himalaya", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.passm.Location = New System.Drawing.Point(230, 424)
        Me.passm.Name = "passm"
        Me.passm.Size = New System.Drawing.Size(97, 24)
        Me.passm.TabIndex = 39
        Me.passm.Text = "PassingMarks"
        '
        'Maxmarks
        '
        Me.Maxmarks.AutoCompleteCustomSource.AddRange(New String() {"15", "30"})
        Me.Maxmarks.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.Maxmarks.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.Maxmarks.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Maxmarks.Location = New System.Drawing.Point(370, 352)
        Me.Maxmarks.Name = "Maxmarks"
        Me.Maxmarks.Size = New System.Drawing.Size(289, 28)
        Me.Maxmarks.TabIndex = 29
        '
        'Maxm
        '
        Me.Maxm.AutoSize = True
        Me.Maxm.Font = New System.Drawing.Font("Microsoft Himalaya", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Maxm.Location = New System.Drawing.Point(230, 359)
        Me.Maxm.Name = "Maxm"
        Me.Maxm.Size = New System.Drawing.Size(77, 24)
        Me.Maxm.TabIndex = 38
        Me.Maxm.Text = "MaxMarks"
        '
        'Duration
        '
        Me.Duration.AutoCompleteCustomSource.AddRange(New String() {"15", "30"})
        Me.Duration.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.Duration.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.Duration.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Duration.Location = New System.Drawing.Point(370, 553)
        Me.Duration.Name = "Duration"
        Me.Duration.Size = New System.Drawing.Size(289, 28)
        Me.Duration.TabIndex = 34
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Himalaya", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(230, 553)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(66, 24)
        Me.Label8.TabIndex = 37
        Me.Label8.Text = "Duration"
        '
        'startexam
        '
        Me.startexam.Location = New System.Drawing.Point(461, 623)
        Me.startexam.Name = "startexam"
        Me.startexam.Size = New System.Drawing.Size(85, 31)
        Me.startexam.TabIndex = 33
        Me.startexam.Text = "Submit"
        Me.startexam.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft JhengHei UI", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(417, 23)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(151, 30)
        Me.Label7.TabIndex = 36
        Me.Label7.Text = "Add Subject"
        '
        'NoofQ
        '
        Me.NoofQ.AutoCompleteCustomSource.AddRange(New String() {"15", "30"})
        Me.NoofQ.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.NoofQ.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.NoofQ.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NoofQ.Location = New System.Drawing.Point(370, 483)
        Me.NoofQ.Name = "NoofQ"
        Me.NoofQ.Size = New System.Drawing.Size(289, 28)
        Me.NoofQ.TabIndex = 32
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Himalaya", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(227, 483)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(118, 24)
        Me.Label6.TabIndex = 35
        Me.Label6.Text = "No Of Questions"
        '
        'Semester
        '
        Me.Semester.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Semester.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Semester.FormattingEnabled = True
        Me.Semester.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6"})
        Me.Semester.Location = New System.Drawing.Point(370, 281)
        Me.Semester.Name = "Semester"
        Me.Semester.Size = New System.Drawing.Size(289, 30)
        Me.Semester.TabIndex = 28
        '
        'Subjectcode
        '
        Me.Subjectcode.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Subjectcode.Location = New System.Drawing.Point(370, 115)
        Me.Subjectcode.Name = "Subjectcode"
        Me.Subjectcode.Size = New System.Drawing.Size(289, 28)
        Me.Subjectcode.TabIndex = 23
        '
        'Subcode
        '
        Me.Subcode.AutoSize = True
        Me.Subcode.Font = New System.Drawing.Font("Microsoft Himalaya", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Subcode.Location = New System.Drawing.Point(230, 115)
        Me.Subcode.Name = "Subcode"
        Me.Subcode.Size = New System.Drawing.Size(91, 24)
        Me.Subcode.TabIndex = 30
        Me.Subcode.Text = "Subject code"
        '
        'SubjectName
        '
        Me.SubjectName.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SubjectName.Location = New System.Drawing.Point(370, 168)
        Me.SubjectName.Name = "SubjectName"
        Me.SubjectName.Size = New System.Drawing.Size(289, 28)
        Me.SubjectName.TabIndex = 25
        '
        'Subname
        '
        Me.Subname.AutoSize = True
        Me.Subname.Font = New System.Drawing.Font("Microsoft Himalaya", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Subname.Location = New System.Drawing.Point(230, 175)
        Me.Subname.Name = "Subname"
        Me.Subname.Size = New System.Drawing.Size(100, 24)
        Me.Subname.TabIndex = 27
        Me.Subname.Text = "Subject Name"
        '
        'Sem
        '
        Me.Sem.AutoSize = True
        Me.Sem.Font = New System.Drawing.Font("Microsoft Himalaya", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sem.Location = New System.Drawing.Point(230, 287)
        Me.Sem.Name = "Sem"
        Me.Sem.Size = New System.Drawing.Size(68, 24)
        Me.Sem.TabIndex = 24
        Me.Sem.Text = "Semester"
        '
        'Course
        '
        Me.Course.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Course.Location = New System.Drawing.Point(370, 220)
        Me.Course.Name = "Course"
        Me.Course.Size = New System.Drawing.Size(289, 28)
        Me.Course.TabIndex = 26
        '
        'Crse
        '
        Me.Crse.AutoSize = True
        Me.Crse.Font = New System.Drawing.Font("Microsoft Himalaya", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Crse.Location = New System.Drawing.Point(230, 227)
        Me.Crse.Name = "Crse"
        Me.Crse.Size = New System.Drawing.Size(55, 24)
        Me.Crse.TabIndex = 22
        Me.Crse.Text = "Course"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(799, 694)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(106, 23)
        Me.Button2.TabIndex = 40
        Me.Button2.Text = "Add Course"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'sessionexam
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(917, 729)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.PassingMarks)
        Me.Controls.Add(Me.passm)
        Me.Controls.Add(Me.Maxmarks)
        Me.Controls.Add(Me.Maxm)
        Me.Controls.Add(Me.Duration)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.startexam)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.NoofQ)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Semester)
        Me.Controls.Add(Me.Subjectcode)
        Me.Controls.Add(Me.Subcode)
        Me.Controls.Add(Me.SubjectName)
        Me.Controls.Add(Me.Subname)
        Me.Controls.Add(Me.Sem)
        Me.Controls.Add(Me.Course)
        Me.Controls.Add(Me.Crse)
        Me.Controls.Add(Me.Button1)
        Me.Name = "sessionexam"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents PassingMarks As TextBox
    Friend WithEvents passm As Label
    Friend WithEvents Maxmarks As TextBox
    Friend WithEvents Maxm As Label
    Friend WithEvents Duration As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents startexam As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents NoofQ As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Semester As ComboBox
    Friend WithEvents Subjectcode As TextBox
    Friend WithEvents Subcode As Label
    Friend WithEvents SubjectName As TextBox
    Friend WithEvents Subname As Label
    Friend WithEvents Sem As Label
    Friend WithEvents Course As TextBox
    Friend WithEvents Crse As Label
    Friend WithEvents Button2 As Button
End Class
