﻿Imports MySql.Data.MySqlClient
Public Class Main
    Dim tpanel As Tpanel
    Dim spanel As sigin
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim mysqlconn As New MySqlConnection
        Dim command As MySqlCommand
        Dim tid As String = Teacherid.Text
        Dim pass As String = Password.Text
        Dim query As String
        Dim Reader As MySqlDataReader

        If tid = "" Or pass = "" Then
            MessageBox.Show("Empty!!")
        Else
            'log
            mysqlconn = New MySqlConnection
            mysqlconn.ConnectionString = "server=localhost;user=root;database=Teacherpanel;port=3306;password=;"
            Try
                mysqlconn.Open()
                query = "select ID,Password from faculty where ID='" + Teacherid.Text + "' and Password='" + Password.Text + "';"
                command = New MySqlCommand(query, mysqlconn)
                Reader = command.ExecuteReader
                If Reader.Read = True Then
                    MessageBox.Show("plz wait..")
                    If tpanel Is Nothing Then
                        tpanel = New Tpanel
                    Else
                        tpanel.Dispose()
                        tpanel = New Tpanel
                    End If
                    Me.Hide()
                    tpanel.Show()
                Else
                    MessageBox.Show("Incorrect Username And Password!!")
                End If
                mysqlconn.Close()
            Catch ex As MySqlException
                MessageBox.Show(ex.Message)
            Finally
                mysqlconn.Dispose()

            End Try
            '


        End If


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Normal
        MaximizeBox = False

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If spanel Is Nothing Then
            spanel = New sigin
        Else
            spanel.Dispose()
            spanel = New sigin
        End If
        Me.Hide()
        spanel.Show()

    End Sub

End Class
