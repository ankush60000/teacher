﻿Imports MySql.Data.MySqlClient

Public Class sessionexam
    Private Sub sessionexam_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        Me.WindowState = FormWindowState.Normal
        MaximizeBox = False
    End Sub

    Dim bool As String = "false"
    Dim mysqlconn As MySqlConnection
    Dim command As MySqlCommand
    Dim previous As New Tpanel
    Dim addcrs As New Addcourse


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If addcrs Is Nothing Then
            addcrs = New Addcourse
        Else
            addcrs.Dispose()
            addcrs = New Addcourse
        End If
        addcrs.Show()
        Me.Close()
    End Sub

    Private Sub startexam_Click(sender As Object, e As EventArgs) Handles startexam.Click
        mysqlconn = New MySqlConnection
        mysqlconn.ConnectionString = "server=localhost;user=root;database=Teacherpanel;port=3306;password=;"
        Dim Reader As MySqlDataReader

        Try
            mysqlconn.Open()
            Dim Query As String = "insert into Teacherpanel.subject(SubjectCode,SubjectName,Course,Semester,MaxMarks,PassingMarks,NumberOfQuestions, Duration) values('" & Subjectcode.Text & "','" & SubjectName.Text & "','" & Course.Text & "','" & Semester.Text & "','" & Maxmarks.Text & "','" & PassingMarks.Text & "','" & NoofQ.Text & "','" & Duration.Text & "')"
            command = New MySqlCommand(Query, mysqlconn)
            Reader = command.ExecuteReader
            MessageBox.Show("Data inserte")
            mysqlconn.Close()
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            mysqlconn.Dispose()
        End Try
        Subjectcode.Text = ""
        SubjectName.Text = ""
        Course.Text = ""
        Semester.Text = ""
        Maxmarks.Text = ""
        NoofQ.Text = ""
        PassingMarks.Text = ""
        Duration.Text = ""
    End Sub

    Private Sub Course_TextChanged(sender As Object, e As EventArgs) Handles Course.TextChanged
        Semester.Items.Clear()
        mysqlconn = New MySqlConnection
        mysqlconn.ConnectionString = "server=localhost;user=root;database=Teacherpanel;port=3306;password=;"
        Dim Reader As MySqlDataReader
        Dim Data As Integer
        Dim temp As Integer = 1
        Try
            mysqlconn.Open()
            Dim Query As String = "Select * from  Teacherpanel.course where CourseName='" & Course.Text & "'"
            command = New MySqlCommand(Query, mysqlconn)
            Reader = command.ExecuteReader
            While Reader.Read
                Data = Reader.GetDecimal("NoOfSemester")
            End While
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            mysqlconn.Close()
            mysqlconn.Dispose()
        End Try

        While temp <= Data
            Semester.Items.Add(temp)
            temp = temp + 1
        End While
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If previous Is Nothing Then
            previous = New Tpanel
        Else
            previous.Dispose()
            previous = New Tpanel
        End If
        previous.Show()
        Me.Close()
    End Sub
End Class