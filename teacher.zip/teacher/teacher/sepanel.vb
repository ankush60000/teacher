﻿Imports MySql.Data.MySqlClient
Public Class sepanel
    Dim query As String
    Dim mysqlconn As MySqlConnection
    Dim command As MySqlCommand
    Dim send As Boolean
    Dim previous As Tpanel
    Private Sub sepanel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        Me.WindowState = FormWindowState.Normal
        MaximizeBox = False

        mysqlconn = New MySqlConnection
        mysqlconn.ConnectionString = "server=localhost;user=root;database=Teacherpanel;port=3306;password=;"
        Dim Reader As MySqlDataReader
        Dim Data As String
        Try
            mysqlconn.Open()
            Dim Query As String = "Select * from  Teacherpanel.Course"
            command = New MySqlCommand(Query, mysqlconn)
            Reader = command.ExecuteReader
            While Reader.Read
                Data = Reader.GetString("Coursename")
                Course.Items.Add(Data)
            End While

            'Semester Detali

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            mysqlconn.Close()
            mysqlconn.Dispose()
        End Try

    End Sub

    Private Sub Course_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Course.SelectedIndexChanged
        Semester.Items.Clear()
        mysqlconn = New MySqlConnection
        mysqlconn.ConnectionString = "server=localhost;user=root;database=Teacherpanel;port=3306;password=;"
        Dim Reader As MySqlDataReader
        Dim Data As Integer
        Dim temp As Integer = 1
        Try
            mysqlconn.Open()
            Dim Query As String = "Select * from  Teacherpanel.course where CourseName='" & Course.SelectedItem & "'"
            command = New MySqlCommand(Query, mysqlconn)
            Reader = command.ExecuteReader
            While Reader.Read
                Data = Reader.GetDecimal("NoOfSemester")
            End While
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            mysqlconn.Close()
            mysqlconn.Dispose()
        End Try

        While temp <= Data
            Semester.Items.Add(temp)
            temp = temp + 1
        End While

    End Sub

    Private Sub Semeter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Semester.SelectedIndexChanged
        mysqlconn = New MySqlConnection
        mysqlconn.ConnectionString = "server=localhost;user=root;database=Teacherpanel;port=3306;password=;"
        Dim Reader As MySqlDataReader
        Dim Data As String
        Try
            mysqlconn.Open()
            Dim Query As String = "Select * from  Teacherpanel.Subject where Course='" & Course.SelectedItem & "' AND Semester=" & Semester.SelectedItem & ";"
            command = New MySqlCommand(Query, mysqlconn)
            Reader = command.ExecuteReader
            While Reader.Read
                Data = Reader.GetString("SubjectName")
                Subject.Items.Add(Data)
            End While
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            mysqlconn.Close()
            mysqlconn.Dispose()
        End Try
    End Sub

    Private Sub Start_Click(sender As Object, e As EventArgs) Handles Start.Click

        If OpenDB() Then
            Datatotext()
        Else
            MessageBox.Show("Error")
        End If
    End Sub

    Sub Datatotext()
        Try
            send = True
            If OpenDB() Then
                mysqlconn.Open()
                query = "UPDATE Teacherpanel.Subject SET StartExam=" & send & " where Course='" & Course.SelectedItem & "' And  Semester=" & Semester.SelectedItem & " And SubjectName='" & Subject.SelectedItem & "';"
                Dim CMD As New MySqlCommand(query, mysqlconn)
                CMD.ExecuteNonQuery()
                mysqlconn.Close()
            End If
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If previous Is Nothing Then
            previous = New Tpanel
        Else
            previous.Dispose()
            previous = New Tpanel
        End If
        previous.Show()
        Me.Close()
    End Sub
End Class