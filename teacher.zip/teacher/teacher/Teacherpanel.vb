﻿Public Class Tpanel
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        Me.WindowState = FormWindowState.Normal
        MaximizeBox = False


    End Sub

    Dim upanel As Form
    Dim spanel As Form
    Dim Sepanel As Form
    Private Sub Button4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If upanel Is Nothing Then
            upanel = New uploadQuestion
        Else
            upanel.Dispose()
            upanel = New uploadQuestion
        End If
        upanel.Show()

    End Sub
    Dim smpanel As Main
    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click

        If smpanel Is Nothing Then
            smpanel = New Main
        Else
            smpanel.Dispose()
            smpanel = New Main
        End If
        Me.Hide()
        smpanel.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If spanel Is Nothing Then
            spanel = New sessionexam
        Else
            spanel.Dispose()
            spanel = New sessionexam
        End If
        Visible = False
        spanel.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If Sepanel Is Nothing Then
            Sepanel = New sepanel
        Else
            Sepanel.Dispose()
            Sepanel = New sepanel
        End If
        Sepanel.Show()


    End Sub
End Class